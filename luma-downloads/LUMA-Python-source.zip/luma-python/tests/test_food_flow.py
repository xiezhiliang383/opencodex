"""Controller state checks only; these do not simulate Android native views."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType
import unittest
from unittest.mock import Mock, patch

root = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'app/src/main/python'))
from luma.core import Album
from luma.food import FOODS

fake_java = ModuleType('java')
fake_java.jclass = lambda name: object
fake_java.dynamic_proxy = lambda interface: object
spec = importlib.util.spec_from_file_location('luma._host_ui',root/'app/src/main/python/luma/ui.py')
ui = importlib.util.module_from_spec(spec)
with patch.dict(sys.modules,{'java':fake_java}):
    spec.loader.exec_module(ui)


class FoodFlowTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.album = Album(temporary.name)
        file = self.album.photos_dir/'food.jpg'
        file.write_bytes(b'fixture')
        self.photo = self.album.add(file,640,480)
        self.app = ui.LumaApp.__new__(ui.LumaApp)
        self.app.a = Mock()
        self.app.album = self.album
        self.app.render = Mock()
        self.app.exporting = False
        self.app.food_request = 0
        self.app.food_photo = None
        self.app.food_confirmed = None
        self.app.food_manual = False
        self.app.selected = self.photo

    def test_result_requires_explicit_confirmation_before_nutrition(self):
        self.app.start_food(self.photo)
        request = self.app.food_request
        self.app.a.recognizeFood.assert_called_once_with(str(self.album.path(self.photo)),request)
        self.app.on_food_result(request,json.dumps([{'label':'banana','score':.9}]))
        self.assertIsNone(self.app.food_confirmed)
        self.assertFalse(self.app.food_busy)
        self.assertEqual(self.app.food_result['suggested_id'],'banana')
        self.app.confirm_food('banana')
        self.assertEqual(self.app.food_confirmed,FOODS['banana'])

    def test_return_cancels_recognition_and_late_results_do_not_reopen_page(self):
        self.app.start_food(self.photo)
        old = self.app.food_request
        self.app.close_food()
        self.app.render.reset_mock()
        self.app.on_food_result(old,json.dumps([{'label':'banana','score':.9}]))
        self.app.render.assert_not_called()
        self.app.a.cancelFoodRecognition.assert_called_once()
        self.assertIsNone(self.app.food_photo)
        self.assertEqual(self.app.selected,self.photo)
        self.assertTrue(self.album.path(self.photo).is_file())

    def test_manual_correction_wins_over_in_flight_result(self):
        self.app.start_food(self.photo)
        old = self.app.food_request
        self.app.open_food_catalog()
        self.app.confirm_food('tomato')
        self.app.on_food_result(old,json.dumps([{'label':'banana','score':.99}]))
        self.assertEqual(self.app.food_confirmed['id'],'tomato')

    def test_failed_recognition_preserves_photo_and_allows_manual_lookup(self):
        self.app.start_food(self.photo)
        self.app.on_food_error(self.app.food_request,'识别失败')
        self.assertFalse(self.app.food_busy)
        self.assertEqual(self.app.food_error,'识别失败')
        self.assertTrue(self.album.path(self.photo).is_file())
        self.app.open_food_catalog()
        self.app.confirm_food('banana')
        self.assertEqual(self.app.food_confirmed['id'],'banana')

    def test_manual_lookup_without_photo_can_show_and_close_result(self):
        self.app.open_food_catalog()
        self.app.confirm_food('banana')
        self.assertTrue(self.app.food_manual)
        self.assertIsNone(self.app.food_photo)
        self.app.a.recognizeFood.assert_not_called()
        self.app.close_food()
        self.assertFalse(self.app.food_manual)

if __name__ == '__main__':
    unittest.main()
