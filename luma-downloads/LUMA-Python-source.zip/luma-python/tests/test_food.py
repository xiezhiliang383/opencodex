from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'app/src/main/python'))
from luma.food import DATA, FOODS, interpret, nutrient_rows, search_foods, spoken_summary


class FoodTests(unittest.TestCase):
    def test_candidate_is_a_suggestion_not_a_confirmed_measurement(self):
        result = interpret([{'label':'banana','score':.8},{'label':'lemon','score':.1}])
        self.assertEqual(result['state'], 'candidate')
        self.assertEqual(result['suggested_id'], 'banana')
        self.assertNotIn('nutrients', result)

    def test_dog_winner_cannot_be_replaced_by_a_low_ranked_food(self):
        result = interpret([{'label':'banana','score':.08},{'label':'Samoyed','score':.82}])
        self.assertEqual(result['state'], 'unsupported')
        self.assertIsNone(result['suggested_id'])
        self.assertIsNone(result['candidates'][0]['food_id'])

    def test_low_score_and_close_rival_require_uncertain_state(self):
        for scores in [(.2,.1),(.48,.45)]:
            result=interpret([{'label':'banana','score':scores[0]},{'label':'lemon','score':scores[1]}])
            self.assertEqual(result['state'],'uncertain')
            self.assertIsNone(result['suggested_id'])

    def test_invalid_scores_cannot_become_candidates(self):
        result=interpret([{'label':'banana','score':score} for score in [float('nan'),float('inf'),-1,2,'0.9']])
        self.assertEqual(result['candidates'],[])
        self.assertIsNone(result['suggested_id'])

    def test_source_records_keep_units_ids_and_reference_state(self):
        self.assertEqual(DATA['basis_g'],100)
        banana=FOODS['banana']
        self.assertEqual(banana['ndb_id'],'09040')
        self.assertEqual(banana['nutrients']['energy_kcal'],89)
        self.assertEqual(banana['nutrients']['protein_g'],1.09)
        self.assertEqual(banana['nutrients']['vitamin_c_mg'],8.7)
        self.assertIn('2015',DATA['source'])
        for food in FOODS.values():
            self.assertIn('raw',food['reference_description'].lower())
            self.assertEqual(len(food['ndb_id']),5)

    def test_mushroom_does_not_assume_an_edible_species(self):
        result=interpret([{'label':'mushroom','score':.98}])
        self.assertIsNone(result['suggested_id'])
        self.assertIn('不能',result['candidates'][0]['name'])

    def test_missing_nutrient_does_not_silently_become_zero(self):
        food=dict(FOODS['banana'],nutrients={})
        self.assertTrue(all(value=='暂无数据' for _,value in nutrient_rows(food)))

    def test_manual_lookup_distinguishes_unsupported_model_classes(self):
        tomato=search_foods('番茄')[0]
        self.assertEqual(tomato['id'],'tomato')
        self.assertEqual(tomato['model_labels'],[])
        self.assertEqual(search_foods('not-a-food'),[])
        self.assertEqual(len(search_foods()),34)

    def test_speech_includes_basis_and_reference_limitation(self):
        speech=spoken_summary(FOODS['banana'])
        self.assertIn('一百克',speech)
        self.assertIn('89 千卡',speech)
        self.assertIn('不是照片中这份食物的实测值',speech)

if __name__ == '__main__':
    unittest.main()
