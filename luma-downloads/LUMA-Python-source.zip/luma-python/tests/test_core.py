import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app/src/main/python'))
from luma.core import Album, Photo, safe_web_url, camera_permission_label


class AlbumTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.album = Album(self.temp.name)

    def photo(self, name='capture.jpg'):
        file = self.album.photos_dir / name
        file.write_bytes(b'photo-fixture')
        return self.album.add(file, 640, 480)

    def test_capture_survives_app_restart_and_delete_only_removes_selected(self):
        first = self.photo('first.jpg')
        second = self.photo('second.jpg')
        restarted = Album(self.temp.name)
        self.assertEqual([p.filename for p in restarted.photos], ['second.jpg', 'first.jpg'])
        self.assertTrue(restarted.delete(second))
        self.assertFalse(restarted.path(second).exists())
        self.assertTrue(restarted.path(first).exists())
        self.assertEqual(Album(self.temp.name).photos, [first])

    def test_failed_metadata_commit_preserves_previous_photo_and_file(self):
        photo = self.photo()
        before = self.album.index.read_bytes()
        with patch('luma.core.os.replace', side_effect=OSError('disk unavailable')):
            with self.assertRaises(OSError):
                self.album.delete(photo)
        self.assertEqual(self.album.index.read_bytes(), before)
        self.assertEqual(self.album.photos, [photo])
        self.assertTrue(self.album.path(photo).exists())

    def test_untrusted_metadata_cannot_escape_app_photo_directory(self):
        for value in ['../outside.jpg', '/tmp/outside.jpg', 'nested/file.jpg', 'capture.png']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.album.path(Photo(value, '2026-01-01T00:00:00+00:00', 640, 480))
        outside = Path(self.temp.name) / 'outside.jpg'
        outside.write_bytes(b'external')
        (self.album.photos_dir / 'link.jpg').symlink_to(outside)
        with self.assertRaises(ValueError):
            self.album.path(Photo('link.jpg', '2026-01-01T00:00:00+00:00', 640, 480))

    def test_missing_or_duplicate_capture_never_creates_extra_records(self):
        photo = self.photo()
        with self.assertRaises(ValueError):
            self.album.add(self.album.path(photo), 640, 480)
        with self.assertRaises(ValueError):
            self.album.add(self.album.photos_dir / 'missing.jpg', 640, 480)
        self.assertEqual(len(self.album.photos), 1)

    def test_corrupt_index_is_not_replaced_with_empty_album(self):
        self.album.index.write_text('not-json', encoding='utf-8')
        with self.assertRaises(json.JSONDecodeError):
            Album(self.temp.name)
        self.assertEqual(self.album.index.read_text(), 'not-json')

    def test_failed_file_cleanup_still_commits_metadata(self):
        photo = self.photo()
        with patch('pathlib.Path.unlink', side_effect=OSError('busy')):
            self.assertFalse(self.album.delete(photo))
        self.assertEqual(Album(self.temp.name).photos, [])


class InteractionTests(unittest.TestCase):
    def test_only_valid_http_links_can_be_opened(self):
        for value in ['https://example.com/a?q=1', 'http://example.com:8080']:
            self.assertTrue(safe_web_url(value))
        for value in ['javascript:alert(1)', 'intent://app', 'file:///private/photo.jpg', 'https://',
                      'https://user:secret@example.com', 'https://:secret@example.com', 'https://example.com:bad',
                      'https://example.com/\npath', 'some text']:
            with self.subTest(value=value):
                self.assertFalse(safe_web_url(value))

    def test_denied_and_permanently_denied_permissions_have_distinct_recovery(self):
        self.assertIn('再次申请', camera_permission_label('denied'))
        self.assertIn('系统设置', camera_permission_label('blocked'))
        self.assertEqual(camera_permission_label('granted'), '已允许')


if __name__ == '__main__':
    unittest.main(verbosity=2)
