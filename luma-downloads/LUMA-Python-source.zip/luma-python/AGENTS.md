# LUMA Python Android

- Python pages and business logic live in `app/src/main/python/`; Android hardware and lifecycle adapters are in `MainActivity.java`.
- This is an independent application. Use this directory; do not create a worktree without a user request.
- Request camera only on explicit user action. Unbind it when leaving the camera page or entering the background.
- Do not add microphone, location, broad media-read, overlay or all-files access permissions.
- Android 10+ exports this app's own photos using MediaStore without library-read permission. Legacy write permission is limited to API 28.
- Preserve photos on failed metadata updates. Validate filenames and commit metadata atomically.
- New services are registered in `luma/core.py` and handled in `LumaApp.service_action`; unavailable services must be labeled accordingly.
- Private service keys and signing material must never enter the source archive or logs.
- Run `python3 -m unittest discover -s tests -v`, then build with `scripts/build.sh`. Validate the final APK signature and manifest, not only source syntax.
- Distinguish emulator validation from physical-device validation. Only call an APK produced after inspecting the actual signed file.
