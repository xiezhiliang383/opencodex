"""Exercise the bundled model with real food and non-food reference photos.

Requires desktop-only ai-edge-litert==1.4.0, numpy and Pillow. These Python
dependencies are NOT needed in the Android app (it uses the native LiteRT API).
Pass a fixture directory containing OpenCV fruits.jpg, TensorFlow burger.jpg,
and PyTorch Hub dog.jpg, downloaded from the URLs in third_party/NOTICE.md.
"""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image
from ai_edge_litert.interpreter import Interpreter

root = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'app/src/main/python'))
from luma.food import interpret

fixtures = Path(sys.argv[1])
model = root/'app/src/main/assets/food/mobilenet_v2.tflite'
assert hashlib.sha256(model.read_bytes()).hexdigest() == 'ff5cb7f9e62c92ebdad971f8a98aa6b3106d82a64587a7787c6a385c9e791339'
labels = (model.parent/'labels.txt').read_text().splitlines()
runtime = Interpreter(model_path=str(model),num_threads=2)
runtime.allocate_tensors()
input = runtime.get_input_details()[0]
output = runtime.get_output_details()[0]
assert input['shape'].tolist() == [1,224,224,3] and input['dtype'] == np.float32
assert output['shape'].tolist() == [1,1001]
checks = [('fruits.jpg','lemon','candidate'),('burger.jpg','cheeseburger','unsupported'),('dog.jpg','Samoyed','unsupported')]
results = []
for filename, expected_label, expected_state in checks:
    image = Image.open(fixtures/filename).convert('RGB')
    width,height = image.size
    side = min(width,height)
    left,top = (width-side)//2,(height-side)//2
    image = image.crop((left,top,left+side,top+side)).resize((224,224),Image.Resampling.BILINEAR)
    pixels=(np.asarray(image,dtype=np.float32)-127.5)/127.5
    runtime.set_tensor(input['index'],pixels[None])
    runtime.invoke()
    probabilities=runtime.get_tensor(output['index'])[0]
    predictions=[dict(label=labels[i],score=float(probabilities[i])) for i in np.argsort(-probabilities)[:5]]
    result=interpret(predictions)
    assert predictions[0]['label'] == expected_label,(filename,predictions)
    assert result['state'] == expected_state,(filename,result)
    results.append(dict(fixture=filename,top=predictions[0],state=result['state']))
report = {'checks_passed':len(checks),'scope':'CPU desktop model inference; not Android hardware validation','results':results}
(root/'artifacts/model-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
