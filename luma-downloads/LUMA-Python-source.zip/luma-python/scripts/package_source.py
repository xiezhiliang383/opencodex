import os
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
excluded = {'.git', '.gradle', '.gradle-cache', '.signing', 'build', 'artifacts', '__pycache__'}
target = root/'artifacts/LUMA-Python-source.zip'
target.parent.mkdir(exist_ok=True)
with ZipFile(target, 'w', ZIP_DEFLATED) as archive:
    for directory, folders, files in os.walk(root):
        folders[:] = [name for name in folders if name not in excluded]
        for name in files:
            if name == 'local.properties' or name.startswith('.env') or name.endswith(('.pyc','.p12','.keystore','.jks')):
                continue
            file = Path(directory)/name
            archive.write(file,Path('luma-python')/file.relative_to(root))
print('Source archive written; signing material and local SDK paths excluded.')
