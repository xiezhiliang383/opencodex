import os
from pathlib import Path
import re
import subprocess
import sys
import hashlib
import io
import json
import struct
from zipfile import ZipFile

apk = Path(sys.argv[1]).resolve()
tools = Path(os.environ.get('ANDROID_HOME', '/workspace/.tools/android-sdk')) / 'build-tools/37.0.0'
badging = subprocess.check_output([str(tools/'aapt2'), 'dump', 'badging', str(apk)], text=True)
declared = subprocess.check_output([str(tools/'aapt2'), 'dump', 'permissions', str(apk)], text=True)
permissions = re.findall(r"^uses-permission(?:-sdk-\d+)?: name='([^']+)'([^\n]*)", declared, re.MULTILINE)
allowed = {'android.permission.CAMERA', 'android.permission.WRITE_EXTERNAL_STORAGE', 'com.luma.pythoncamera.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION'}
assert "package: name='com.luma.pythoncamera'" in badging
assert "versionName='0.2.0'" in badging and "versionCode='2'" in badging
assert re.search(r"(?:minSdkVersion|sdkVersion):'24'", badging)
assert "native-code: 'arm64-v8a' 'x86_64'" in badging
assert {p for p,_ in permissions} <= allowed, permissions
assert any(p=='android.permission.CAMERA' for p,_ in permissions)
assert any(p=='android.permission.WRITE_EXTERNAL_STORAGE' and "maxSdkVersion='28'" in flags for p,flags in permissions)
with ZipFile(apk) as archive:
    names = archive.namelist()
    assert any(n.startswith('assets/chaquopy/') for n in names)
    assert 'lib/arm64-v8a/libpython3.12.so' in names
    assert 'lib/x86_64/libpython3.12.so' in names
    assert 'classes.dex' in names
    assert hashlib.sha256(archive.read('assets/food/mobilenet_v2.tflite')).hexdigest() == 'ff5cb7f9e62c92ebdad971f8a98aa6b3106d82a64587a7787c6a385c9e791339'
    assert len(archive.read('assets/food/labels.txt').decode().splitlines()) == 1001
    assert any(n.endswith('/libtensorflowlite_jni.so') for n in names)
    assert 'assets/food/LICENSE.txt' in names
    with ZipFile(io.BytesIO(archive.read('assets/chaquopy/app.imy'))) as python_app:
        records = json.loads(python_app.read('luma/data/nutrition.json'))
        assert len(records['foods']) == 34 and records['basis_g'] == 100
        assert sum(bool(item['model_labels']) for item in records['foods']) == 22
    for name in names:
        if name.endswith('.so'):
            binary = archive.read(name)
            assert binary[:4] == b'\x7fELF' and binary[4] == 2, name
            endian = '<' if binary[5] == 1 else '>'
            offset = struct.unpack_from(endian+'Q',binary,32)[0]
            size,count = struct.unpack_from(endian+'HH',binary,54)
            for index in range(count):
                start = offset+index*size
                if struct.unpack_from(endian+'I',binary,start)[0] == 1:
                    assert struct.unpack_from(endian+'Q',binary,start+48)[0] >= 16384,name
    assert not any(n.endswith(('.p12','.keystore')) for n in names)
print('APK v0.2.0, both ABIs, Python, bundled offline model, labels and minimal permissions verified.')
(apk.parent/'apk-badging.txt').write_text(badging)
(apk.parent/'apk-permissions.txt').write_text(declared)
