import os
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

apk = Path(sys.argv[1]).resolve()
tools = Path(os.environ.get('ANDROID_HOME', '/workspace/.tools/android-sdk')) / 'build-tools/37.0.0'
badging = subprocess.check_output([str(tools/'aapt2'), 'dump', 'badging', str(apk)], text=True)
declared = subprocess.check_output([str(tools/'aapt2'), 'dump', 'permissions', str(apk)], text=True)
permissions = re.findall(r"^uses-permission(?:-sdk-\d+)?: name='([^']+)'([^\n]*)", declared, re.MULTILINE)
allowed = {'android.permission.CAMERA', 'android.permission.WRITE_EXTERNAL_STORAGE', 'com.luma.pythoncamera.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION'}
assert "package: name='com.luma.pythoncamera'" in badging
assert re.search(r"(?:minSdkVersion|sdkVersion):'24'", badging)
assert "native-code: 'arm64-v8a' 'x86_64'" in badging
assert {p for p,_ in permissions} <= allowed, permissions
assert any(p=='android.permission.CAMERA' for p,_ in permissions)
assert any(p=='android.permission.WRITE_EXTERNAL_STORAGE' and "maxSdkVersion='28'" in flags for p,flags in permissions)
with ZipFile(apk) as archive:
    names = archive.namelist()
    assert any(n.startswith('assets/chaquopy/') for n in names)
    assert 'lib/arm64-v8a/libpython3.12.so' in names
    assert 'lib/x86_64/libpython3.12.so' in names
    assert 'classes.dex' in names
    assert not any(n.endswith(('.p12','.keystore')) for n in names)
print('APK package, Android 7+ support, both ABIs, Python runtime and minimal permissions verified.')
(apk.parent/'apk-badging.txt').write_text(badging)
(apk.parent/'apk-permissions.txt').write_text(declared)
