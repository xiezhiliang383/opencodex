"""Preserve managed proxy and TLS verification for the Java build."""
import os
from pathlib import Path
from urllib.parse import urlparse

proxy = urlparse(os.environ.get('HTTPS_PROXY', ''))
directory = Path(os.environ['GRADLE_USER_HOME'])
directory.mkdir(parents=True, exist_ok=True)
path = directory / 'gradle.properties'
existing = path.read_text() if path.exists() else ''
keys = ('systemProp.http.proxy', 'systemProp.https.proxy', 'systemProp.http.nonProxyHosts=', 'systemProp.javax.net.ssl.trustStore=')
lines = [line for line in existing.splitlines() if not line.startswith(keys)]
if proxy.hostname:
    if proxy.username or proxy.password:
        raise SystemExit('Authenticated proxy needs a separate credential binding.')
    for protocol in ('http', 'https'):
        lines += [f'systemProp.{protocol}.proxyHost={proxy.hostname}', f'systemProp.{protocol}.proxyPort={proxy.port or 80}']
    lines.append('systemProp.http.nonProxyHosts=localhost|127.*|[::1]')
    trust = Path(os.environ.get('LUMA_JAVA_TRUSTSTORE', '/etc/ssl/certs/java/cacerts'))
    if trust.is_file():
        lines.append(f'systemProp.javax.net.ssl.trustStore={trust}')
path.write_text('\n'.join(lines)+'\n')
