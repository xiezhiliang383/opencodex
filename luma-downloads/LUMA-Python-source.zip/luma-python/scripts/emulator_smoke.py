"""Exercise the installed APK on a dedicated emulator; never target a physical device."""
import json
import os
from pathlib import Path
import re
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
ADB = str(Path(os.environ.get('ANDROID_HOME','/workspace/.tools/android-sdk'))/'platform-tools/adb')
SERIAL = os.environ.get('LUMA_TEST_SERIAL','emulator-5554')
assert SERIAL.startswith('emulator-'), 'This smoke test is restricted to an emulator.'
PACKAGE = 'com.luma.pythoncamera'
checks = []

def adb(*args, timeout=45, binary=False):
    result = subprocess.run([ADB,'-s',SERIAL,*args],capture_output=True,timeout=timeout,check=True)
    return result.stdout if binary else result.stdout.decode('utf-8',errors='replace')

def hierarchy():
    adb('shell','uiautomator','dump','--compressed','/sdcard/luma-window.xml')
    return ET.fromstring(adb('exec-out','cat','/sdcard/luma-window.xml'))

def wait_node(predicate, attempts=10):
    last = None
    for _ in range(attempts):
        try:
            last = hierarchy()
            for node in last.iter('node'):
                if predicate(node.attrib):
                    return node.attrib
        except (subprocess.SubprocessError, ET.ParseError):
            pass
        time.sleep(1)
    if last is not None:
        (ROOT/'artifacts/failed-ui.xml').write_bytes(ET.tostring(last,encoding='utf-8'))
    raise AssertionError('Expected UI element did not appear')

def find_text(text):
    return wait_node(lambda n:n.get('text')==text or n.get('content-desc')==text)

def tap(node):
    values = [int(v) for v in re.findall(r'\d+',node['bounds'])]
    adb('shell','input','tap',str((values[0]+values[2])//2),str((values[1]+values[3])//2))

def click(text):
    tap(find_text(text))

def shot(name):
    (ROOT/'artifacts'/name).write_bytes(adb('exec-out','screencap','-p',binary=True))

def passed(name):
    checks.append(name)
    print('PASS:',name,flush=True)
    (ROOT/'artifacts/emulator-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))

adb('shell','input','keyevent','82')
adb('shell','settings','put','global','window_animation_scale','0')
adb('shell','settings','put','global','transition_animation_scale','0')
adb('shell','settings','put','global','animator_duration_scale','0')
adb('shell','am','force-stop',PACKAGE)
adb('shell','am','start','-W','-n',PACKAGE+'/.MainActivity',timeout=60)
find_text('开启相机')
shot('python-camera.png')
passed('Python application starts and renders the camera page')

click('开启相机')
deny = wait_node(lambda n:n.get('resource-id','').endswith('permission_deny_button'))
tap(deny)
wait_node(lambda n:'相机权限尚未允许' in n.get('text',''))
click('相册')
find_text('故事，从第一张开始')
passed('Camera denial leaves the album accessible')

click('相机')
click('开启相机')
allow = wait_node(lambda n:n.get('resource-id','').endswith('permission_allow_foreground_only_button'))
tap(allow)
tap(wait_node(lambda n:n.get('text')=='● 拍照' and n.get('enabled')=='true',attempts=20))
wait_node(lambda n:n.get('text')=='● 拍照' and n.get('enabled')=='true',attempts=20)
click('相册')
wait_node(lambda n:n.get('text','').startswith('1 张照片'))
shot('python-gallery.png')
passed('Camera permission and a real CameraX capture create an album photo')

adb('shell','am','force-stop',PACKAGE)
adb('shell','am','start','-W','-n',PACKAGE+'/.MainActivity',timeout=60)
click('相册')
wait_node(lambda n:n.get('text','').startswith('1 张照片'))
tap(wait_node(lambda n:n.get('content-desc','').startswith('查看照片 ')))
find_text('存到手机')
shot('python-photo.png')
passed('Photo persists across process restart and opens in preview')

click('存到手机')
wait_node(lambda n:'已保存到手机相册' in n.get('text',''),attempts=20)
passed('MediaStore export succeeds on Android 15 without library read permission')

click('分享')
time.sleep(2)
shot('python-share.png')
adb('shell','input','keyevent','4')
find_text('存到手机')
passed('System share sheet opens and returns to the photo')

click('删除')
find_text('确认删除')
click('保留')
find_text('存到手机')
click('删除')
click('确认删除')
find_text('故事，从第一张开始')
passed('Delete confirmation supports cancellation and removes only the selected photo')

click('设置')
find_text('系统权限')
click('外观：浅色')
find_text('外观：深色')
shot('python-settings.png')
adb('shell','am','force-stop',PACKAGE)
adb('shell','am','start','-W','-n',PACKAGE+'/.MainActivity',timeout=60)
click('设置')
find_text('外观：深色')
passed('Theme preference persists across process restart')

click('服务')
find_text('打开扫码识别')
shot('python-services.png')
click('打开扫码识别')
find_text('QR SCAN')
passed('Registered QR service opens the CameraX scanning mode')

logs = adb('logcat','-d','-s','LumaPython:E','AndroidRuntime:E')
(ROOT/'artifacts/runtime-errors.log').write_text(logs)
assert 'Python startup failed' not in logs and 'FATAL EXCEPTION' not in logs, logs
print('Completed',len(checks),'emulator checks.',flush=True)
