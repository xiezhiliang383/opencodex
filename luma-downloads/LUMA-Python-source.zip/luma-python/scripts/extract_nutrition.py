"""Extract selected USDA SR28 records without estimating missing nutrients.

Usage: python3 scripts/extract_nutrition.py /path/to/usda.sql3
Input mirror: https://github.com/alyssaq/usda-sqlite (USDA SR28 data).
"""
import json
from pathlib import Path
import sqlite3
import sys

RECORDS = [
    ('banana', '香蕉', '水果', 9040, ['banana']),
    ('apple', '青苹果（Granny Smith）', '水果', 9502, ['Granny Smith']),
    ('strawberry', '草莓', '水果', 9316, ['strawberry']),
    ('orange', '橙子', '水果', 9200, ['orange']),
    ('lemon', '柠檬', '水果', 9150, ['lemon']),
    ('fig', '无花果', '水果', 9089, ['fig']),
    ('pineapple', '菠萝', '水果', 9266, ['pineapple']),
    ('jackfruit', '菠萝蜜', '水果', 9144, ['jackfruit']),
    ('custard_apple', '牛心番荔枝', '水果', 9086, ['custard apple']),
    ('pomegranate', '石榴', '水果', 9286, ['pomegranate']),
    ('cabbage', '卷心菜', '蔬菜', 11109, ['head cabbage']),
    ('broccoli', '西兰花', '蔬菜', 11090, ['broccoli']),
    ('cauliflower', '菜花', '蔬菜', 11135, ['cauliflower']),
    ('zucchini', '西葫芦', '蔬菜', 11477, ['zucchini']),
    ('spaghetti_squash', '金丝南瓜', '蔬菜', 11492, ['spaghetti squash']),
    ('acorn_squash', '橡果南瓜', '蔬菜', 11482, ['acorn squash']),
    ('butternut_squash', '奶油南瓜', '蔬菜', 11485, ['butternut squash']),
    ('cucumber', '黄瓜', '蔬菜', 11205, ['cucumber']),
    ('artichoke', '洋蓟', '蔬菜', 11007, ['artichoke']),
    ('green_pepper', '青甜椒', '蔬菜', 11333, ['bell pepper']),
    ('cardoon', '刺菜蓟', '蔬菜', 11122, ['cardoon']),
    ('sweet_corn', '甜玉米', '蔬菜', 11167, ['ear', 'corn']),
    ('tomato', '番茄', '蔬菜', 11529, []),
    ('carrot', '胡萝卜', '蔬菜', 11124, []),
    ('potato', '土豆（带皮）', '蔬菜', 11352, []),
    ('grape', '葡萄', '水果', 9132, []),
    ('watermelon', '西瓜', '水果', 9326, []),
    ('kiwi', '猕猴桃', '水果', 9148, []),
    ('mango', '芒果', '水果', 9176, []),
    ('pear', '梨', '水果', 9252, []),
    ('peach', '黄桃', '水果', 9236, []),
    ('eggplant', '茄子', '蔬菜', 11209, []),
    ('lettuce', '绿叶生菜', '蔬菜', 11253, []),
    ('spinach', '菠菜', '蔬菜', 11457, []),
]
NUTRIENTS = {
    'energy_kcal': 208, 'protein_g': 203, 'fat_g': 204,
    'carbohydrate_g': 205, 'fiber_g': 291, 'sugars_g': 269,
    'vitamin_c_mg': 401, 'potassium_mg': 306, 'water_g': 255,
}

def extract(database, destination):
    connection = sqlite3.connect(f'file:{Path(database).resolve()}?mode=ro', uri=True)
    foods = []
    for key, name, category, ndb, labels in RECORDS:
        description = connection.execute('SELECT long_desc FROM food WHERE id=?', (ndb,)).fetchone()[0]
        assert 'raw' in description.lower(), description
        values = dict(connection.execute('SELECT nutrient_id,amount FROM nutrition WHERE food_id=?', (ndb,)))
        foods.append(dict(id=key, name=name, category=category, ndb_id=f'{ndb:05d}',
                          reference_description=description, state='生鲜原料，每 100 克可食部分',
                          model_labels=labels,
                          nutrients={key: values.get(number) for key, number in NUTRIENTS.items()}))
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(dict(version=1, source='USDA National Nutrient Database, SR28 (2015)',
        source_url='https://github.com/alyssaq/usda-sqlite/tree/master/data', basis_g=100, foods=foods),
        ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(f'Extracted {len(foods)} food records with original NDB identifiers.')

if __name__ == '__main__':
    extract(sys.argv[1], Path(__file__).resolve().parents[1]/'app/src/main/python/luma/data/nutrition.json')
