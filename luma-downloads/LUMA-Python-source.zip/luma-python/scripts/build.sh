#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export JAVA_HOME="${JAVA_HOME:-/workspace/.tools/jdk17}"
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_HOME="${ANDROID_HOME:-/workspace/.tools/android-sdk}"
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$PWD/.gradle-cache}"
export LUMA_BUILD_PYTHON="${LUMA_BUILD_PYTHON:-$(command -v python3)}"
export LUMA_KEYSTORE="$PWD/.signing/preview.p12"
mkdir -p .signing artifacts "$GRADLE_USER_HOME"
chmod 700 .signing
if [ ! -f .signing/password ]; then (umask 077; openssl rand -hex 24 > .signing/password); fi
export LUMA_SIGNING_PASSWORD
LUMA_SIGNING_PASSWORD="$(cat .signing/password)"
if [ ! -f "$LUMA_KEYSTORE" ]; then
  keytool -genkeypair -noprompt -storetype PKCS12 -keystore "$LUMA_KEYSTORE" \
    -storepass:env LUMA_SIGNING_PASSWORD -keypass:env LUMA_SIGNING_PASSWORD \
    -alias luma-python -keyalg RSA -keysize 3072 -validity 3650 \
    -dname 'CN=LUMA Python Preview, O=LUMA'
fi
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties
python3 scripts/gradle_network.py
python3 -m unittest discover -s tests -v
./gradlew :app:assembleRelease --no-daemon --console=plain
cp app/build/outputs/apk/release/app-release.apk artifacts/LUMA-Python-0.2.0.apk
"$ANDROID_HOME/build-tools/37.0.0/apksigner" verify --verbose artifacts/LUMA-Python-0.2.0.apk
"$ANDROID_HOME/build-tools/37.0.0/zipalign" -c -P 16 4 artifacts/LUMA-Python-0.2.0.apk
(cd artifacts && sha256sum LUMA-Python-0.2.0.apk > LUMA-Python-0.2.0.apk.sha256)
python3 scripts/verify_apk.py artifacts/LUMA-Python-0.2.0.apk
