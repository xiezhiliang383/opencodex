# LUMA 相机 · Python Android 版

独立可安装的 Android 相机应用。页面、交互、相册和服务注册使用 **Python 3.12** 编写；通过 **Chaquopy 17.1** 调用安卓原生界面、CameraX、MediaStore 和系统分享。无需 Expo Go、电脑运行服务、登录或在线后端。

## 下载和安装

安装包：`artifacts/LUMA-Python-0.2.0.apk`。与 0.1.0 相同包名和签名，可覆盖升级并保留应用相册；不要先卸载。

- Android 7.0 / API 24 及以上。
- 包含 `arm64-v8a` 和 `x86_64`，适合常见 64 位手机及 x86_64 模拟器；不支持仅 32 位的老手机。
- 下载后打开 APK，按 Android 提示允许当前浏览器或文件管理器安装此来源的应用。
- 安装来源授权由系统管理，App 不申请、也不会自动更改。
- 相机权限仅在点击开启相机或主动申请时弹出；拒绝后仍可查看相册和设置。

此包使用本项目专用的内部预览签名，不是商店发行版。更新需要相同包名和证书，请保留开发环境的 `.signing/`。卸载会删除应用内照片，请先导出重要照片。

## 已实现

- 真实摄像头预览、拍照、前后镜头、闪光灯、九宫格。
- 离开相机页或进入后台时释放相机。
- 应用私有相册、图片预览、时间、确认删除。
- 保存到系统相册和系统分享。
- 离线二维码识别、复制内容、主动打开 HTTP/HTTPS 网址。
- 离线蔬果识物：相机选择“识物”，或在照片详情选择“识别这张照片中的蔬果”。
- 22 类蔬果提供模型候选，确认名称后查询营养；34 种原料可手动检索。番茄、胡萝卜、土豆等当前仅支持手动查询。
- 每 100 克生鲜可食部分的能量、蛋白质、脂肪、碳水、纤维、糖、维生素 C、钾与水分；保留 USDA SR28（2015）原始 NDB 编号和条目。
- 中文营养摘要朗读与停止。需要手机已安装可离线使用的中文语音；未安装时给出设置提示，不申请麦克风。
- 浅色/深色外观、权限状态、系统设置恢复入口。
- 服务注册表，后续可增加更专业的识别模型、滤镜、云相册等。

当前应用没有联网权限，不会上传照片。二维码网址由用户主动选择后交给系统浏览器打开。扩展联网服务时需新增普通联网声明并明确用户的数据操作。

## 识物范围和数据边界

离线模型是通用 MobileNet V2 图像分类器，不是专业食品检测模型。请一次拍一种蔬果，居中并保持光线充足。模型可能误识别；结果显示候选与模型得分，必须手动确认或纠正后才展示营养。它不会称重、分割一盘里的多种食品、判断成熟度或分析熟食配料。

营养数值来自 USDA SR28（2015）静态资料，不是从照片测得，也不是实时数据库。全部按 **100 克生鲜可食部分**；相似品种、不同成熟度、烹饪及去皮可能改变数值。请核对结果页的原始食物条目，例如青甜椒、甜玉米。未收录的食品不生成营养数据；未提供的指标显示“暂无数据”。蘑菇图像不会被映射为某一种可食蘑菇。

识别模型、完整标签和营养表都随 APK 打包，不需要 API Key、联网下载模型或后端。取消或识别失败不会删除原照片。来源与许可见 [third_party/NOTICE.md](./third_party/NOTICE.md)。

## 源码结构

```text
app/src/main/python/main.py          Python 入口
app/src/main/python/luma/ui.py       页面、导航、用户交互
app/src/main/python/luma/core.py     相册存储、链接规则、服务注册
app/src/main/python/luma/food.py     候选解释、食材查找、营养展示和朗读文本
app/src/main/python/luma/data/       精选 USDA 营养记录
app/src/main/assets/food/           离线模型、标签与许可证
app/src/main/java/.../MainActivity.java  安卓相机/权限/文件原生桥接
app/src/main/java/.../FoodClassifier.java  LiteRT 推理与图像预处理
app/src/main/AndroidManifest.xml     系统权限与组件声明
tests/test_core.py                  Python 核心测试
scripts/build.sh                    APK 构建与签名校验
scripts/verify_apk.py               APK 最终清单与内嵌运行时检查
```

新增服务：在 `core.py` 的 `SERVICES` 中注册，接入 `LumaApp.service_action`。耗时识图或上传应在本地照片保存完成后执行；服务商私钥放在后端，不能打进 APK。

## 本地构建

需要 Python 3.12、JDK 17、Android SDK Platform 37.0、Build Tools 37.0.0。项目使用 Gradle 9.4.1 和 Android Gradle Plugin 9.2.1；包装器已配置官方分发 SHA-256 校验。

```bash
export JAVA_HOME=/你的/jdk17
export ANDROID_HOME=/你的/android-sdk
export PATH="$JAVA_HOME/bin:$PATH"
bash scripts/build.sh
```

云环境现有工具路径已作为脚本默认值，可用上述变量覆盖。脚本生成本地随机签名密码并将签名材料保存在 `.signing/`；不会打印密码，不会把密钥放进源码包。

代理环境使用已有 HTTPS 代理和受管理的 Java CA 库，不关闭 TLS 校验。构建需要 Google Android Maven、Maven Central 和 Gradle 官方源，不依赖 React Native 原生库域名。

## 测试和验证

```bash
python3 -m unittest discover -s tests -v
./gradlew :app:testQrDecoder :app:testFoodPixels
python3 scripts/verify_apk.py artifacts/LUMA-Python-0.2.0.apk
"$ANDROID_HOME/build-tools/37.0.0/apksigner" verify --verbose artifacts/LUMA-Python-0.2.0.apk
"$ANDROID_HOME/build-tools/37.0.0/zipalign" -c -P 16 4 artifacts/LUMA-Python-0.2.0.apk
cd artifacts && sha256sum --check LUMA-Python-0.2.0.apk.sha256
```

详细系统权限、拒绝恢复和操作流程见 [权限与交互说明](./权限与交互说明.md)。具体执行结果和真机验证边界见 [验证记录](./VALIDATION.md)。
