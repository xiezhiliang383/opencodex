# LUMA 相机 · Python Android 版

独立可安装的 Android 相机应用。页面、交互、相册和服务注册使用 **Python 3.12** 编写；通过 **Chaquopy 17.1** 调用安卓原生界面、CameraX、MediaStore 和系统分享。无需 Expo Go、电脑运行服务、登录或在线后端。

## 下载和安装

安装包：`artifacts/LUMA-Python-0.1.0.apk`。

- Android 7.0 / API 24 及以上。
- 包含 `arm64-v8a` 和 `x86_64`，适合常见 64 位手机及 x86_64 模拟器；不支持仅 32 位的老手机。
- 下载后打开 APK，按 Android 提示允许当前浏览器或文件管理器安装此来源的应用。
- 安装来源授权由系统管理，App 不申请、也不会自动更改。
- 相机权限仅在点击开启相机或主动申请时弹出；拒绝后仍可查看相册和设置。

此包使用本项目专用的内部预览签名，不是商店发行版。更新需要相同包名和证书，请保留开发环境的 `.signing/`。卸载会删除应用内照片，请先导出重要照片。

## 已实现

- 真实摄像头预览、拍照、前后镜头、闪光灯、九宫格。
- 离开相机页或进入后台时释放相机。
- 应用私有相册、图片预览、时间、确认删除。
- 保存到系统相册和系统分享。
- 离线二维码识别、复制内容、主动打开 HTTP/HTTPS 网址。
- 浅色/深色外观、权限状态、系统设置恢复入口。
- 服务注册表，后续可增加识图、滤镜、云相册等。

当前应用没有联网权限，不会上传照片。二维码网址由用户主动选择后交给系统浏览器打开。扩展联网服务时需新增普通联网声明并明确用户的数据操作。

## 源码结构

```text
app/src/main/python/main.py          Python 入口
app/src/main/python/luma/ui.py       页面、导航、用户交互
app/src/main/python/luma/core.py     相册存储、链接规则、服务注册
app/src/main/java/.../MainActivity.java  安卓相机/权限/文件原生桥接
app/src/main/AndroidManifest.xml     系统权限与组件声明
tests/test_core.py                  Python 核心测试
scripts/build.sh                    APK 构建与签名校验
scripts/verify_apk.py               APK 最终清单与内嵌运行时检查
```

新增服务：在 `core.py` 的 `SERVICES` 中注册，接入 `LumaApp.service_action`。耗时识图或上传应在本地照片保存完成后执行；服务商私钥放在后端，不能打进 APK。

## 本地构建

需要 Python 3.12、JDK 17、Android SDK Platform 37.0、Build Tools 37.0.0。项目使用 Gradle 9.4.1 和 Android Gradle Plugin 9.2.1；包装器已配置官方分发 SHA-256 校验。

```bash
export JAVA_HOME=/你的/jdk17
export ANDROID_HOME=/你的/android-sdk
export PATH="$JAVA_HOME/bin:$PATH"
bash scripts/build.sh
```

云环境现有工具路径已作为脚本默认值，可用上述变量覆盖。脚本生成本地随机签名密码并将签名材料保存在 `.signing/`；不会打印密码，不会把密钥放进源码包。

代理环境使用已有 HTTPS 代理和受管理的 Java CA 库，不关闭 TLS 校验。构建需要 Google Android Maven、Maven Central 和 Gradle 官方源，不依赖 React Native 原生库域名。

## 测试和验证

```bash
python3 -m unittest discover -s tests -v
python3 scripts/verify_apk.py artifacts/LUMA-Python-0.1.0.apk
"$ANDROID_HOME/build-tools/37.0.0/apksigner" verify --verbose artifacts/LUMA-Python-0.1.0.apk
"$ANDROID_HOME/build-tools/37.0.0/zipalign" -c -P 16 4 artifacts/LUMA-Python-0.1.0.apk
cd artifacts && sha256sum --check LUMA-Python-0.1.0.apk.sha256
```

详细系统权限、拒绝恢复和操作流程见 [权限与交互说明](./权限与交互说明.md)。具体执行结果和真机验证边界见 [验证记录](./VALIDATION.md)。
