package com.luma.pythoncamera;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;
import java.nio.ByteBuffer;
import java.util.Arrays;
import org.junit.Test;
import static org.junit.Assert.*;

public class ScanDecoderTest {
    @Test public void decodesRealQrImageOffline() throws Exception {
        String text = "https://example.org/luma?photo=1";
        BitMatrix image = new QRCodeWriter().encode(text,BarcodeFormat.QR_CODE,256,256);
        byte[] bytes = new byte[256*256];
        for (int y=0;y<256;y++) for(int x=0;x<256;x++) bytes[y*256+x] = image.get(x,y) ? 0 : (byte)255;
        assertEquals(text,ScanDecoder.decode(bytes,256,256));
    }
    @Test public void blankFrameDoesNotProduceFalseResult() {
        byte[] bytes = new byte[128*128]; Arrays.fill(bytes,(byte)255);
        assertNull(ScanDecoder.decode(bytes,128,128));
    }
    @Test public void respectsCameraRowAndPixelStride() {
        byte[] padded = {10,0,20,0,99,99,30,0,40,0};
        assertArrayEquals(new byte[]{10,20,30,40},ScanDecoder.packLuminance(ByteBuffer.wrap(padded),2,2,6,2));
    }
}
