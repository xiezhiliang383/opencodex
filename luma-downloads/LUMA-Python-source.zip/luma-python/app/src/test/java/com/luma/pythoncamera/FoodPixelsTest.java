package com.luma.pythoncamera;

import java.nio.ByteBuffer;
import org.junit.Test;
import static org.junit.Assert.*;

public class FoodPixelsTest {
    @Test public void rgbOrderMatchesMobileNetContract() {
        ByteBuffer input=FoodPixels.normalize(new int[]{0xFF00FF80});
        assertEquals(-1f,input.getFloat(),0f);
        assertEquals(1f,input.getFloat(),0f);
        assertEquals((128f-127.5f)/127.5f,input.getFloat(),1e-6f);
        assertFalse(input.hasRemaining());
    }
    @Test public void blackAndWhiteHaveExpectedRangeRegardlessOfAlpha() {
        ByteBuffer input=FoodPixels.normalize(new int[]{0x00000000,0xFFFFFFFF});
        for(int i=0;i<3;i++) assertEquals(-1f,input.getFloat(),0f);
        for(int i=0;i<3;i++) assertEquals(1f,input.getFloat(),0f);
        assertEquals(24,input.capacity());
    }
}
