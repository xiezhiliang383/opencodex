# Offline model and nutrition provenance

## Image classifier

- MobileNet V2, float32, 224 x 224 RGB, ImageNet 1001 labels including background.
- File: `app/src/main/assets/food/mobilenet_v2.tflite`.
- Source: https://github.com/tensorflow/tflite-support/blob/master/tensorflow_lite_support/cc/test/testdata/task/vision/mobilenet_v2_1.0_224.tflite
- Download SHA-256: `ff5cb7f9e62c92ebdad971f8a98aa6b3106d82a64587a7787c6a385c9e791339`.
- Labels are the model's appended `labels.txt`; the background offset is retained.
- Repository license: Apache 2.0, copied in `TENSORFLOW-LICENSE`.
- Input checked with LiteRT 1.4.0: float32 `[1,224,224,3]`, `(RGB-127.5)/127.5`; output `[1,1001]`.
- Android runtime: `com.google.ai.edge.litert:litert:1.4.0`, Apache 2.0.
- This is a general single-image classifier, not a food-specific detector or a model that measures nutrition. Some classes are ambiguous; user confirmation is always required. There is no supported recognition claim for every fruit or vegetable.

## Nutrition facts

- USDA National Nutrient Database for Standard Reference, Release 28 (2015).
- Public factual nutrient data obtained from the SR28 raw-data mirror at https://github.com/alyssaq/usda-sqlite/tree/master/data .
- Input database mirror: https://github.com/alyssaq/usda-sqlite/blob/master/usda.sql3 .
- Extraction script: `scripts/extract_nutrition.py`; only 34 selected raw-food facts are bundled. No mirror application code is redistributed.
- Original NDB IDs and English food descriptions are retained in each record. This release uses an older reference dataset and does not claim current live data.
- All values are per 100 grams of edible raw material. Unavailable values remain null, never invented or silently replaced by zero.
- Image categories such as bell pepper or corn do not determine the exact cultivar. Users must check the selected reference item (green sweet pepper / raw sweet corn). No species or edibility determination is made for mushrooms.

## Desktop verification images (not bundled)

- OpenCV sample (mixed fruit; visible lemon): https://raw.githubusercontent.com/opencv/opencv/master/samples/data/fruits.jpg
- TensorFlow reference burger: https://raw.githubusercontent.com/tensorflow/tflite-support/master/tensorflow_lite_support/cc/test/testdata/task/vision/burger.jpg
- PyTorch Hub reference dog: https://raw.githubusercontent.com/pytorch/hub/master/images/dog.jpg

These three checks verify label indexing and a food/non-food lookup path. They are not an accuracy benchmark and do not establish Android camera behavior or recognition quality across the supported categories.
