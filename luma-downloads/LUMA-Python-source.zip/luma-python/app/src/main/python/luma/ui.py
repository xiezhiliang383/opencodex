"""All pages, navigation and user interactions are written in Python.

Android's native views and CameraX are accessed through the Chaquopy Java bridge.
The storage and service rules in core.py remain independently testable.
"""
from datetime import datetime
import json
from java import dynamic_proxy, jclass
from .core import Album, SERVICES, camera_permission_label, safe_web_url
from .food import DATA, FOODS, interpret, search_foods, nutrient_rows, spoken_summary

Linear = jclass('android.widget.LinearLayout')
Frame = jclass('android.widget.FrameLayout')
Text = jclass('android.widget.TextView')
Button = jclass('android.widget.Button')
Image = jclass('android.widget.ImageView')
Scroll = jclass('android.widget.ScrollView')
Edit = jclass('android.widget.EditText')
Gravity = jclass('android.view.Gravity')
Color = jclass('android.graphics.Color')
Typeface = jclass('android.graphics.Typeface')
Drawable = jclass('android.graphics.drawable.GradientDrawable')
Alert = jclass('android.app.AlertDialog$Builder')
Scale = jclass('android.widget.ImageView$ScaleType')


class Click(dynamic_proxy(jclass('android.view.View$OnClickListener'))):
    def __init__(self, action):
        super().__init__()
        self.action = action

    def onClick(self, view):
        self.action()


class DialogClick(dynamic_proxy(jclass('android.content.DialogInterface$OnClickListener'))):
    def __init__(self, action):
        super().__init__()
        self.action = action

    def onClick(self, dialog, which):
        self.action()


LIGHT = dict(bg='#F6F7F4', card='#FFFFFF', text='#17221D', muted='#748078', soft='#EAF1E6', accent='#193E2B')
DARK = dict(bg='#101713', card='#1B251E', text='#EDF2EB', muted='#9AAA9D', soft='#253C2C', accent='#BFF16A')


class LumaApp:
    def __init__(self, activity):
        self.a = activity
        self.density = float(activity.getResources().getDisplayMetrics().density)
        self.tab = 'camera'
        self.selected = None
        self.dark = bool(activity.darkMode())
        self.front = False
        self.scan = False
        self.identify = False
        self.food_photo = None
        self.food_result = None
        self.food_confirmed = None
        self.food_busy = False
        self.food_error = ''
        self.food_manual = False
        self.food_query = ''
        self.food_request = 0
        self.grid = True
        self.flash = 2  # CameraX OFF=2, AUTO=0, ON=1.
        self.busy = False
        self.exporting = False
        self.ready = False
        self.shutter = None
        self.listeners = []
        self.load_album()
        self.render()

    def load_album(self):
        self.load_error = ''
        try:
            self.album = Album(str(self.a.filesDirectory()))
        except Exception:
            self.album = None
            self.load_error = '无法读取本地相册。请保留应用数据，稍后重试。'

    def dp(self, value):
        return int(value * self.density + .5)

    def layout(self, width=-1, height=-2, weight=None):
        width = self.dp(width) if width >= 0 else width
        height = self.dp(height) if height >= 0 else height
        return Linear.LayoutParams(width, height) if weight is None else Linear.LayoutParams(width, height, float(weight))

    def box(self, vertical=True, color=None, padding=0):
        view = Linear(self.a)
        view.setOrientation(1 if vertical else 0)
        view.setPadding(self.dp(padding), self.dp(padding), self.dp(padding), self.dp(padding))
        if color:
            self.background(view, color)
        return view

    def background(self, view, color, radius=0, stroke=None):
        background = Drawable()
        background.setColor(Color.parseColor(color))
        background.setCornerRadius(float(self.dp(radius)))
        if stroke:
            background.setStroke(self.dp(1), Color.parseColor(stroke))
        view.setBackground(background)

    def text(self, value, size=14, color=None, bold=False, padding=0):
        view = Text(self.a)
        view.setText(str(value))
        view.setTextSize(float(size))
        view.setTextColor(Color.parseColor(color or self.theme['text']))
        view.setPadding(self.dp(padding), self.dp(padding), self.dp(padding), self.dp(padding))
        view.setLineSpacing(float(self.dp(4)), 1.0)
        if bold:
            view.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        return view

    def click(self, view, callback):
        def safe_action():
            try:
                callback()
            except Exception:
                self.a.message('操作未完成，请保留照片后重试。')
        listener = Click(safe_action)
        self.listeners.append(listener)
        view.setOnClickListener(listener)

    def button(self, label, callback, primary=False, dark=False):
        view = Button(self.a)
        view.setText(label)
        view.setTextSize(13.0)
        view.setAllCaps(False)
        view.setContentDescription(label)
        view.setMinHeight(self.dp(46))
        view.setPadding(self.dp(12), 0, self.dp(12), 0)
        view.setTextColor(Color.parseColor('#193E2B' if primary else '#EDF2EB' if dark else self.theme['accent']))
        self.background(view, '#BFF16A' if primary else '#26332B' if dark else self.theme['soft'], 20)
        self.click(view, callback)
        return view

    def space(self, parent, height):
        parent.addView(Text(self.a), self.layout(-1, height))

    def heading(self, parent, title, subtitle):
        parent.addView(self.text('LUMA / PYTHON EDITION', 10, self.theme['muted'], True))
        self.space(parent, 16)
        parent.addView(self.text(title + '.', 31, bold=True))
        self.space(parent, 8)
        parent.addView(self.text(subtitle, 12, self.theme['muted']))
        self.space(parent, 24)

    def scroll_body(self, parent):
        scroll = Scroll(self.a)
        scroll.setFillViewport(True)
        content = self.box(padding=22)
        scroll.addView(content)
        parent.addView(scroll, self.layout(-1, 0, 1))
        return content

    def render(self):
        self.a.stopCamera()
        self.a.stopSpeech()
        self.ready = False
        self.shutter = None
        self.listeners = []
        self.theme = DARK if self.dark else LIGHT
        root = self.box(color='#101713' if self.tab == 'camera' else self.theme['bg'])
        if self.load_error:
            body = self.box(padding=26)
            body.setGravity(Gravity.CENTER)
            body.addView(self.text(self.load_error, 16, '#EDF2EB'))
            body.addView(self.button('重新读取', self.retry_load, True))
            root.addView(body, self.layout(-1, 0, 1))
        elif self.food_photo is not None or self.food_manual:
            self.build_food(root)
        elif self.selected is not None:
            self.build_detail(root)
        elif self.tab == 'camera':
            self.build_camera(root)
        elif self.tab == 'gallery':
            self.build_gallery(root)
        elif self.tab == 'services':
            self.build_services(root)
        else:
            self.build_settings(root)
        if self.selected is None and self.food_photo is None and not self.food_manual and not self.load_error:
            nav = self.box(False, '#17211B' if self.tab == 'camera' else self.theme['card'], 8)
            for key, label in [('camera', '相机'), ('gallery', '相册'), ('services', '服务'), ('settings', '设置')]:
                active = key == self.tab
                btn = self.button(label, lambda key=key: self.navigate(key), dark=self.tab == 'camera')
                if active:
                    btn.setTextColor(Color.parseColor('#BFF16A' if self.tab == 'camera' else self.theme['accent']))
                    btn.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                params = self.layout(0, 48, 1)
                params.setMargins(self.dp(3), 0, self.dp(3), 0)
                nav.addView(btn, params)
            root.addView(nav, self.layout(-1, 66))
        self.a.setMainContent(root)

    def retry_load(self):
        self.load_album()
        self.render()

    def navigate(self, tab):
        if self.busy or self.exporting:
            self.a.message('正在保存，请稍候。')
            return
        self.tab = tab
        self.selected = None
        self.render()

    def build_camera(self, root):
        body = self.box(padding=16)
        root.addView(body, self.layout(-1, 0, 1))
        header = self.box(False)
        header.addView(self.text('LUMA  /', 27, '#F1F6EE', True), self.layout(0, -2, 1))
        tag = self.text('YOUR MOMENTS', 9, '#BFF16A')
        tag.setGravity(Gravity.CENTER_VERTICAL)
        header.addView(tag, self.layout(-2, 44))
        body.addView(header)
        body.addView(self.text('把日常，留在此刻', 11, '#91A096'))
        self.space(body, 17)
        holder = Frame(self.a)
        self.background(holder, '#1D2921', 22, '#314035')
        holder.setClipToOutline(True)
        body.addView(holder, self.layout(-1, 0, 1))
        granted = str(self.a.cameraPermissionState()) == 'granted'
        if not granted:
            state = str(self.a.cameraPermissionState())
            empty = self.box(padding=24)
            empty.setGravity(Gravity.CENTER)
            title = self.text('从一个镜头开始', 22, '#F1F6EE', True)
            empty.addView(title)
            self.space(empty, 18)
            copy = '拍照、识物和扫码需要摄像头。\n只在相机页和前台使用，不在后台拍摄。'
            if state == 'blocked':
                copy = '相机权限已关闭，请到系统设置恢复。\n已有照片和其他页面仍可使用。'
            elif state == 'denied':
                copy = '相机权限尚未允许，可再次申请。\n也可以先去相册查看已有照片。'
            description = self.text(copy, 12, '#9EAEA2')
            description.setGravity(Gravity.CENTER)
            empty.addView(description)
            self.space(empty, 22)
            empty.addView(self.button('前往系统设置' if state == 'blocked' else '开启相机', self.a.requestCameraPermission, True))
            holder.addView(empty, Frame.LayoutParams(-1,-1))
        else:
            tools = self.box(False, padding=8)
            self.flash_button = self.button('闪光关' if self.flash == 2 else '闪光自动' if self.flash == 0 else '闪光开', self.toggle_flash, dark=True)
            tools.addView(self.flash_button, self.layout(92, 42))
            mode = self.text('QR SCAN' if self.scan else 'FOOD ID' if self.identify else 'PHOTO', 10, '#EDF2EB', True)
            mode.setGravity(Gravity.CENTER)
            tools.addView(mode, self.layout(0, 42, 1))
            tools.addView(self.button('辅助线', self.toggle_grid, dark=True), self.layout(82,42))
            params = Frame.LayoutParams(-1,self.dp(60),Gravity.TOP)
            holder.addView(tools, params)
            self.camera_hint = self.text('正在连接镜头…', 11, '#EDF2EB', padding=12)
            self.camera_hint.setGravity(Gravity.CENTER)
            holder.addView(self.camera_hint, Frame.LayoutParams(-1,self.dp(48),Gravity.BOTTOM))
        self.space(body, 12)
        modes = self.box(False)
        for mode, label in [('photo', '拍照'), ('food', '识物'), ('scan', '扫码')]:
            btn = self.button(label, lambda value=mode: self.change_mode(value), dark=True)
            if mode == ('scan' if self.scan else 'food' if self.identify else 'photo'):
                btn.setTextColor(Color.parseColor('#BFF16A'))
            modes.addView(btn, self.layout(0,42,1))
        body.addView(modes)
        self.space(body, 10)
        actions = self.box(False)
        actions.setGravity(Gravity.CENTER_VERTICAL)
        actions.addView(self.button('相册', lambda: self.navigate('gallery'), dark=True), self.layout(76,52))
        self.shutter = self.button('重新扫描' if self.scan else '拍照识物' if self.identify else '● 拍照', self.take_photo, True)
        self.shutter.setEnabled(granted and self.ready and not self.busy)
        params = self.layout(0,65,1)
        params.setMargins(self.dp(14),0,self.dp(14),0)
        actions.addView(self.shutter,params)
        actions.addView(self.button('翻转', self.switch_camera, dark=True),self.layout(76,52))
        body.addView(actions)
        self.space(body, 10)
        hint = self.text('蔬果放在画面中央 · 一次拍一种 · 完全离线' if self.identify else '每个平凡的瞬间，都值得被记住', 9, '#819086')
        hint.setGravity(Gravity.CENTER)
        body.addView(hint)
        if granted:
            self.a.startCamera(holder, self.front, self.flash, self.scan, self.grid)

    def change_mode(self, value):
        if self.busy:
            return
        self.scan = value == 'scan'
        self.identify = value == 'food'
        self.render()

    def switch_camera(self):
        if not self.busy:
            self.front = not self.front
            self.render()

    def toggle_grid(self):
        if not self.busy:
            self.grid = not self.grid
            self.render()

    def toggle_flash(self):
        value = (self.flash + 1) % 3
        if self.a.changeFlash(value):
            self.flash = value
            self.flash_button.setText({2: '闪光关', 0: '闪光自动', 1: '闪光开'}[value])

    def take_photo(self):
        if self.scan:
            self.a.resumeScanning()
        elif self.ready and not self.busy:
            self.busy = True
            self.shutter.setEnabled(False)
            self.shutter.setText('保存中…')
            self.a.capturePhoto()

    def on_camera_ready(self):
        self.ready = True
        if self.shutter is not None:
            self.shutter.setEnabled(not self.busy)
            self.camera_hint.setText('将二维码对准画面' if self.scan else '将一种蔬果放在画面中央' if self.identify else '镜头已就绪 · 自由记录')

    def on_camera_error(self, message):
        self.ready = False
        if self.shutter is not None:
            self.shutter.setEnabled(False)
            self.camera_hint.setText('连接失败，点击翻转或切换页面重试')
        self.a.message(str(message))

    def on_photo_saved(self, path, width, height):
        self.busy = False
        try:
            photo = self.album.add(str(path), int(width), int(height))
            if self.identify:
                self.start_food(photo)
                return
            self.a.message('已保存到应用相册')
        except Exception:
            self.a.message('照片文件已保留，但相册记录保存失败，请保留应用数据。')
        if self.shutter is not None:
            self.shutter.setText('拍照识物' if self.identify else '● 拍照')
            self.shutter.setEnabled(self.ready)

    def on_capture_error(self, message):
        self.busy = False
        self.a.message(str(message))
        if self.shutter is not None:
            self.shutter.setText('拍照识物' if self.identify else '● 拍照')
            self.shutter.setEnabled(self.ready)

    def build_gallery(self, root):
        body = self.scroll_body(root)
        self.heading(body, '我的瞬间', f'{len(self.album.photos)} 张照片 · 本地私有保存')
        if not self.album.photos:
            self.space(body, 70)
            body.addView(self.text('故事，从第一张开始', 23, bold=True))
            self.space(body, 15)
            body.addView(self.text('日落、路边的小花，或今天的自己。\n去拍一张你想留下的照片吧。', 13, self.theme['muted']))
            self.space(body, 28)
            body.addView(self.button('去拍第一张', lambda: self.navigate('camera'), True))
            return
        for offset in range(0,len(self.album.photos),3):
            row = self.box(False)
            for photo in self.album.photos[offset:offset+3]:
                image = Image(self.a)
                image.setScaleType(Scale.CENTER_CROP)
                image.setContentDescription('查看照片 ' + photo.filename)
                self.background(image, self.theme['soft'], 13)
                image.setClipToOutline(True)
                self.click(image, lambda photo=photo: self.open_photo(photo))
                params = self.layout(0,135,1)
                params.setMargins(self.dp(3),self.dp(3),self.dp(3),self.dp(3))
                row.addView(image,params)
                self.a.loadPhoto(image,str(self.album.path(photo)),480)
            for _ in range(3-len(self.album.photos[offset:offset+3])):
                row.addView(Text(self.a),self.layout(0,135,1))
            body.addView(row)

    def open_photo(self, photo):
        self.selected = photo
        self.render()

    def build_detail(self, root):
        body = self.box(color='#101713',padding=18)
        root.addView(body,self.layout(-1,0,1))
        body.addView(self.button('返回相册',self.close_photo,dark=True))
        timestamp = datetime.fromisoformat(self.selected.created_at).astimezone().strftime('%Y-%m-%d %H:%M')
        date = self.text(timestamp,12,'#9AAA9D',padding=14)
        date.setGravity(Gravity.CENTER)
        body.addView(date)
        image = Image(self.a)
        image.setScaleType(Scale.FIT_CENTER)
        body.addView(image,self.layout(-1,0,1))
        self.a.loadPhoto(image,str(self.album.path(self.selected)),1600)
        self.detail_status = self.text('',12,'#BFF16A',padding=10)
        body.addView(self.detail_status)
        body.addView(self.button('识别这张照片中的蔬果',lambda:self.start_food(self.selected),True))
        self.space(body,8)
        row = self.box(False)
        self.export_button = self.button('存到手机',self.export_photo,True)
        for button in [self.export_button,self.button('分享',self.share_photo,dark=True),self.button('删除',self.confirm_delete,dark=True)]:
            params = self.layout(0,50,1)
            params.setMargins(self.dp(3),0,self.dp(3),0)
            row.addView(button,params)
        body.addView(row)
        self.space(body,8)
        body.addView(self.button('系统权限设置',self.a.openPermissionSettings,dark=True))

    def close_photo(self):
        if not self.exporting:
            self.selected = None
            self.render()

    def export_photo(self):
        if self.exporting:
            return
        self.exporting = True
        self.export_button.setEnabled(False)
        self.detail_status.setText('正在保存到手机…')
        self.a.savePhotoToSystem(str(self.album.path(self.selected)))

    def on_export_result(self, success, message, blocked):
        self.exporting = False
        if self.selected is not None:
            self.detail_status.setText(str(message))
            self.export_button.setEnabled(True)
        self.a.message(str(message))

    def share_photo(self):
        if not self.exporting:
            self.a.sharePhoto(str(self.album.path(self.selected)))

    def confirm_delete(self):
        if self.exporting:
            return
        positive = DialogClick(self.delete_selected)
        negative = DialogClick(lambda: None)
        self.listeners.extend([positive,negative])
        Alert(self.a).setTitle('删除这张照片？').setMessage('仅删除应用内照片，不会删除已保存到系统相册的副本。').setPositiveButton('确认删除',positive).setNegativeButton('保留',negative).show()

    def delete_selected(self):
        try:
            cleaned = self.album.delete(self.selected)
            self.selected = None
            self.render()
            if not cleaned:
                self.a.message('相册记录已删除，文件暂未清理，请稍后重试。')
        except Exception:
            self.a.message('删除未完成，请稍后重试。')

    def build_services(self, root):
        body = self.scroll_body(root)
        self.heading(body,'镜头之外','从拍照开始，让相机拥有更多可能。')
        hero = self.box(color=self.theme['soft'],padding=23)
        hero.addView(self.text('MORE THAN A CAMERA',10,self.theme['accent'],True))
        self.space(hero,15)
        hero.addView(self.text('从拍照开始，\n不止于拍照。',25,bold=True))
        body.addView(hero)
        self.space(body,25)
        for service in SERVICES:
            body.addView(self.text(service['title'],20,bold=True))
            self.space(body,8)
            body.addView(self.text(service['description'],12,self.theme['muted']))
            self.space(body,14)
            body.addView(self.button('打开'+service['title'],lambda action=service['action']:self.service_action(action),True))
            self.space(body,25)
        body.addView(self.button('手动查询蔬果营养',self.open_food_catalog))
        self.space(body,35)
        body.addView(self.text('下一种可能，由你决定',19,bold=True))
        self.space(body,10)
        body.addView(self.text('滤镜、云相册……\n更多服务可以继续加入，当前尚未接入。',13,self.theme['muted']))

    def service_action(self, action):
        if action == 'scan':
            self.scan = True
            self.identify = False
            self.navigate('camera')
        elif action == 'food':
            self.scan = False
            self.identify = True
            self.navigate('camera')

    def start_food(self, photo):
        if self.exporting:
            return
        self.food_photo = photo
        self.food_confirmed = None
        self.food_result = None
        self.food_error = ''
        self.food_manual = False
        self.food_busy = True
        self.food_request += 1
        self.render()
        self.a.recognizeFood(str(self.album.path(photo)),self.food_request)

    def on_food_result(self, request, result):
        if int(request) != self.food_request or self.food_photo is None:
            return
        try:
            self.food_result = interpret(json.loads(str(result)))
            self.food_error = ''
        except Exception:
            self.food_result = None
            self.food_error = '识别结果读取失败，请重试或手动查询。'
        self.food_busy = False
        self.render()

    def on_food_error(self, request, message):
        if int(request) == self.food_request and self.food_photo is not None:
            self.food_busy = False
            self.food_error = str(message)
            self.render()

    def open_food_catalog(self):
        self.a.cancelFoodRecognition()
        self.food_request += 1
        self.food_busy = False
        self.food_manual = True
        self.food_confirmed = None
        self.food_query = ''
        self.render()

    def confirm_food(self, food_id):
        self.food_confirmed = FOODS[food_id]
        self.food_manual = False
        # Manual lookup has no photo; keep its page active.
        if self.food_photo is None:
            self.food_manual = True
        self.render()

    def close_food(self):
        self.a.cancelFoodRecognition()
        self.food_request += 1
        self.food_busy = False
        self.food_photo = None
        self.food_confirmed = None
        self.food_manual = False
        self.render()

    def build_food(self, root):
        body = self.scroll_body(root)
        body.addView(self.button('返回照片' if self.selected else '返回',self.close_food))
        self.space(body,20)
        self.heading(body,'蔬果识物','离线识别 · 确认名称 · 营养资料')
        if self.food_photo is not None:
            image = Image(self.a)
            image.setScaleType(Scale.FIT_CENTER)
            body.addView(image,self.layout(-1,190))
            self.a.loadPhoto(image,str(self.album.path(self.food_photo)),640)
            self.space(body,15)
        if self.food_confirmed is not None:
            food = self.food_confirmed
            body.addView(self.text(food['name'],26,bold=True))
            body.addView(self.text('你已确认食材 · '+food['category'],12,self.theme['accent']))
            self.space(body,14)
            body.addView(self.text('每 100 克可食部分 · 生鲜原料',16,bold=True))
            body.addView(self.text('以下是资料参考值，品种、成熟度和做法会造成差异。\n照片无法测出重量或实际营养含量；熟食不能直接套用。',12,self.theme['muted']))
            self.space(body,15)
            for label, value in nutrient_rows(food):
                row = self.box(False,padding=8)
                row.addView(self.text(label,14),self.layout(0,-2,1))
                row.addView(self.text(value,14,self.theme['accent'],True))
                body.addView(row)
            self.space(body,18)
            body.addView(self.button('朗读营养摘要',lambda:self.a.speakFood(spoken_summary(food)),True))
            self.space(body,10)
            body.addView(self.button('停止朗读',self.a.stopSpeech))
            self.space(body,10)
            body.addView(self.button('更换食材 / 纠正识别',self.open_food_catalog))
            self.space(body,20)
            body.addView(self.text(DATA['source']+'\nNDB 编号：'+food['ndb_id']+'\n原始条目：'+food['reference_description'],11,self.theme['muted']))
            self.space(body,12)
            body.addView(self.button('查看营养数据来源',lambda:self.a.openWeb(DATA['source_url'])))
            return
        if self.food_manual:
            body.addView(self.text('选择食材后查看参考数据',20,bold=True))
            supported = sum(bool(food['model_labels']) for food in FOODS.values())
            body.addView(self.text(f'资料库含 {len(FOODS)} 种蔬果，其中 {supported} 种提供模型候选。\n番茄、胡萝卜等当前请手动查询。请核对品种和生鲜状态。',12,self.theme['muted']))
            entry = Edit(self.a)
            entry.setSingleLine(True)
            entry.setTextColor(Color.parseColor(self.theme['text']))
            entry.setHintTextColor(Color.parseColor(self.theme['muted']))
            entry.setHint('搜索名称，例如：香蕉、番茄')
            entry.setContentDescription('搜索食材名称')
            entry.setText(self.food_query)
            body.addView(entry,self.layout(-1,52))
            def search():
                self.food_query = str(entry.getText().toString())
                self.render()
            body.addView(self.button('搜索',search))
            matches = search_foods(self.food_query)
            if not matches:
                body.addView(self.text('未收录这个食材，请修改搜索词。',13,self.theme['muted']))
            for food in matches:
                self.space(body,10)
                suffix = ' · 可识别候选' if food['model_labels'] else ' · 手动查询'
                body.addView(self.button(food['name']+suffix,lambda key=food['id']:self.confirm_food(key)))
            return
        if self.food_busy:
            body.addView(self.text('正在手机上识别…',22,bold=True))
            body.addView(self.text('首次需要加载模型。照片不会上传，可返回取消。',12,self.theme['muted']))
            return
        if self.food_error:
            body.addView(self.text(self.food_error,15,self.theme['accent']))
        elif self.food_result:
            state = self.food_result['state']
            title = {'candidate':'找到一个蔬果候选，请核对', 'uncertain':'暂时不能确定，请选择或重拍', 'unsupported':'未识别为已收录的蔬果'}[state]
            body.addView(self.text(title,20,bold=True))
            body.addView(self.text('模型得分不是正确率。请核对名称、品种和颜色后再查营养。',12,self.theme['muted']))
            seen = set()
            for candidate in self.food_result['candidates']:
                key = candidate['food_id']
                self.space(body,10)
                score = f"{candidate['score']*100:.1f}%"
                if key and key not in seen:
                    seen.add(key)
                    body.addView(self.button('确认 '+candidate['name']+' · 得分 '+score,lambda key=key:self.confirm_food(key),key==self.food_result['suggested_id']))
                elif not key:
                    body.addView(self.text(candidate['name']+' · 得分 '+score+' · 未收录营养资料',12,self.theme['muted']))
        self.space(body,20)
        body.addView(self.button('重新识别这张照片',lambda:self.start_food(self.food_photo)))
        self.space(body,10)
        body.addView(self.button('手动选择食材 / 纠正结果',self.open_food_catalog,True))
        self.space(body,12)
        body.addView(self.text('建议只拍一种蔬果，放在画面中央并保持光线充足。\n当前为单物体分类模型，不支持称重、多物体分割或熟食配料分析。',12,self.theme['muted']))

    def on_scan_result(self, content):
        value = str(content)
        copy = DialogClick(lambda: self.a.copyText(value))
        again = DialogClick(self.a.resumeScanning)
        builder = Alert(self.a).setTitle('二维码识别成功').setMessage(value[:10000]).setNegativeButton('继续扫描',again).setNeutralButton('复制内容',copy)
        self.listeners.extend([copy,again])
        if safe_web_url(value):
            open_url = DialogClick(lambda:self.a.openWeb(value))
            self.listeners.append(open_url)
            builder.setPositiveButton('打开网址',open_url)
        # Keep scanning paused until explicitly resumed or the camera remounts.
        builder.setCancelable(False).show()

    def build_settings(self, root):
        body = self.scroll_body(root)
        self.heading(body,'恰如你所愿','少一点打扰，多一点自由。')
        body.addView(self.text('LUMA 相机 · Python',22,bold=True))
        body.addView(self.text('独立 Android App · v0.2.0',11,self.theme['muted']))
        self.space(body,25)
        body.addView(self.button('外观：深色' if self.dark else '外观：浅色',self.toggle_theme))
        self.space(body,24)
        body.addView(self.text('系统权限',19,bold=True))
        self.space(body,15)
        state = str(self.a.cameraPermissionState())
        body.addView(self.text('摄像头 · '+camera_permission_label(state),13,self.theme['accent']))
        self.space(body,8)
        body.addView(self.text('仅用于拍照、蔬果识物和二维码识别，离开相机页即关闭。',12,self.theme['muted']))
        if state != 'granted':
            self.space(body,12)
            body.addView(self.button('申请相机权限' if state != 'blocked' else '恢复相机权限',self.a.requestCameraPermission))
        self.space(body,18)
        body.addView(self.text('照片保存 · '+('无需额外授权' if self.a.androidApi()>=29 else '保存时申请写入权限'),13,self.theme['accent']))
        body.addView(self.text('不读取手机相册，只保存你选择的本应用照片。',12,self.theme['muted']))
        self.space(body,15)
        body.addView(self.button('打开系统权限设置',self.a.openPermissionSettings))
        self.space(body,28)
        body.addView(self.text('你的照片，由你掌握',19,bold=True))
        self.space(body,12)
        body.addView(self.text(f'当前 {len(self.album.photos)} 张照片保存在本应用内，不会自动上传。\n\n卸载应用会删除私有照片，请提前存到手机或分享备份。\n\n不需要账号，不使用麦克风、位置、通讯录或全盘访问。',12,self.theme['muted']))

    def toggle_theme(self):
        self.dark = not self.dark
        self.a.setDarkMode(self.dark)
        self.render()

    def on_resume(self):
        if not self.busy and (self.food_photo is not None or self.food_manual or self.tab in ('camera','settings') and not self.selected):
            self.render()

    def on_permission_result(self, code):
        if int(code) == 100:
            self.render()
        elif int(code) == 101:
            self.a.message('授权操作已完成。请在照片详情再次点击存到手机。')

    def on_back(self):
        if self.food_photo is not None or self.food_manual:
            self.close_food()
            return True
        if self.exporting or self.busy:
            self.a.message('正在保存，请稍候。')
            return True
        if self.selected is not None:
            self.close_photo()
            return True
        if self.tab != 'camera':
            self.navigate('camera')
            return True
        if self.scan or self.identify:
            self.scan = False
            self.identify = False
            self.render()
            return True
        return False
