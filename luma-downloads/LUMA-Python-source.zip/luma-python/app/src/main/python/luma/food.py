"""Offline label interpretation and sourced, per-100g reference nutrition."""
import json
import math
from pkgutil import get_data

DATA = json.loads(get_data('luma', 'data/nutrition.json').decode('utf-8'))
FOODS = {item['id']: item for item in DATA['foods']}
LABELS = {label: food for food in FOODS.values() for label in food['model_labels']}
NUTRIENTS = (
    ('energy_kcal', '能量', '千卡'), ('protein_g', '蛋白质', '克'),
    ('fat_g', '脂肪', '克'), ('carbohydrate_g', '碳水化合物', '克'),
    ('fiber_g', '膳食纤维', '克'), ('sugars_g', '总糖', '克'),
    ('vitamin_c_mg', '维生素 C', '毫克'), ('potassium_mg', '钾', '毫克'),
    ('water_g', '水分', '克'),
)
OTHER_NAMES = {'cheeseburger': '芝士汉堡', 'hotdog': '热狗', 'pizza': '披萨',
    'ice cream': '冰淇淋', 'bagel': '贝果', 'French loaf': '法棍',
    'mushroom': '蘑菇（不能据此判断种类或可食性）', 'guacamole': '牛油果酱',
    'consomme': '清汤', 'hot pot': '火锅', 'espresso': '浓缩咖啡',
    'meat loaf': '肉饼', 'burrito': '墨西哥卷饼', 'pretzel': '椒盐脆饼'}

def interpret(predictions):
    """Judge the global winner, never cherry-pick a low-ranked food label."""
    ranked = []
    for entry in predictions:
        label, score = entry.get('label'), entry.get('score')
        if not isinstance(label, str) or not isinstance(score, (int, float)):
            continue
        if not math.isfinite(score) or not 0 <= score <= 1:
            continue
        food = LABELS.get(label)
        ranked.append(dict(label=label, score=score, food_id=food['id'] if food else None,
                           name=food['name'] if food else OTHER_NAMES.get(label, label)))
    ranked.sort(key=lambda item: item['score'], reverse=True)
    ranked = ranked[:5]
    top = ranked[0] if ranked else None
    gap = top['score'] - (ranked[1]['score'] if len(ranked) > 1 else 0) if top else 0
    supported = bool(top and top['food_id'])
    certain = supported and top['score'] >= .35 and gap >= .10
    return dict(candidates=ranked, suggested_id=top['food_id'] if certain else None,
                state='candidate' if certain else 'uncertain' if supported else 'unsupported')

def search_foods(query=''):
    query = str(query).strip().casefold()
    return [food for food in FOODS.values() if not query or
            query in (food['name']+' '+food['id']+' '+food['reference_description']).casefold()]

def nutrient_rows(food):
    result = []
    for key, label, unit in NUTRIENTS:
        value = food['nutrients'].get(key)
        result.append((label, '暂无数据' if value is None else f'{value:g} {unit}'))
    return result

def spoken_summary(food):
    values = '，'.join(f'{label}{value}' for label, value in nutrient_rows(food)[:5])
    return f"{food['name']}。以下为每一百克生鲜可食部分的资料参考值：{values}。不是照片中这份食物的实测值。"
