"""Android-independent photo storage and service rules."""
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from urllib.parse import urlsplit


@dataclass(frozen=True)
class Photo:
    filename: str
    created_at: str
    width: int
    height: int


class Album:
    def __init__(self, directory):
        self.root = Path(directory).resolve()
        self.photos_dir = self.root / 'photos'
        self.photos_dir.mkdir(parents=True, exist_ok=True)
        self.index = self.root / 'album.json'
        self.photos = []
        if self.index.exists():
            data = json.loads(self.index.read_text(encoding='utf-8'))
            if data.get('version') != 1 or not isinstance(data.get('photos'), list):
                raise ValueError('相册记录格式异常，请保留应用数据后重试。')
            for value in data['photos']:
                photo = Photo(**value)
                self.path(photo)  # Reject traversal rather than trusting stored filenames.
                datetime.fromisoformat(photo.created_at)
                if photo.width <= 0 or photo.height <= 0:
                    raise ValueError('照片尺寸记录异常。')
                self.photos.append(photo)

    def path(self, photo):
        name = photo.filename
        if not isinstance(name, str) or not name.endswith('.jpg') or Path(name).name != name:
            raise ValueError('照片路径异常。')
        path = (self.photos_dir / name).resolve()
        if path.parent != self.photos_dir:
            raise ValueError('照片不在应用相册内。')
        return path

    def _commit(self, updated):
        temporary = self.index.with_suffix('.tmp')
        with temporary.open('w', encoding='utf-8') as stream:
            json.dump({'version': 1, 'photos': [asdict(p) for p in updated]}, stream, ensure_ascii=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, self.index)
        self.photos = updated

    def add(self, path, width, height):
        path = Path(path).resolve()
        if path.parent != self.photos_dir or not path.is_file():
            raise ValueError('拍摄文件尚未保存到应用目录。')
        if width <= 0 or height <= 0:
            raise ValueError('照片尺寸无效。')
        if any(p.filename == path.name for p in self.photos):
            raise ValueError('照片已记录，不能重复保存。')
        photo = Photo(path.name, datetime.now(timezone.utc).isoformat(), int(width), int(height))
        self.path(photo)
        self._commit([photo, *self.photos])
        return photo

    def delete(self, photo):
        if photo not in self.photos:
            raise ValueError('照片已不存在。')
        path = self.path(photo)
        self._commit([p for p in self.photos if p != photo])
        try:
            path.unlink(missing_ok=True)
            return True
        except OSError:
            return False


def safe_web_url(value):
    try:
        if any(c.isspace() for c in value) or any(ord(c) < 32 for c in value):
            return False
        parsed = urlsplit(value)
        _ = parsed.port  # Validate malformed ports without making a network request.
        return parsed.scheme.lower() in ('http', 'https') and bool(parsed.hostname) and parsed.username is None and parsed.password is None
    except (ValueError, TypeError):
        return False


def camera_permission_label(state):
    return {'granted': '已允许', 'unasked': '尚未授权', 'denied': '未允许，可再次申请',
            'blocked': '已关闭，请在系统设置恢复'}.get(state, '尚未检查')


SERVICES = ({'id': 'qr', 'title': '扫码识别', 'description': '读取二维码内容，由你决定是否打开网址。', 'action': 'scan'},)
