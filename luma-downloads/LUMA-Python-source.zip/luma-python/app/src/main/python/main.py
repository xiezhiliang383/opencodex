"""Entry point invoked by the minimal Android host."""
from luma.ui import LumaApp


def start(activity):
    return LumaApp(activity)
