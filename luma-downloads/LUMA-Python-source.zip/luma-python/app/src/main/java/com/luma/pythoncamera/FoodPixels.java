package com.luma.pythoncamera;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Model's verified RGB / [-1, 1] float input, shared with JVM tests. */
public final class FoodPixels {
    public static ByteBuffer normalize(int[] pixels) {
        ByteBuffer input = ByteBuffer.allocateDirect(pixels.length * 3 * 4).order(ByteOrder.nativeOrder());
        for (int pixel : pixels) {
            input.putFloat((((pixel >> 16) & 255) - 127.5f) / 127.5f);
            input.putFloat((((pixel >> 8) & 255) - 127.5f) / 127.5f);
            input.putFloat(((pixel & 255) - 127.5f) / 127.5f);
        }
        input.rewind();
        return input;
    }
}
