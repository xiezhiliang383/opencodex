package com.luma.pythoncamera;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.exifinterface.media.ExifInterface;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.*;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {
    private PyObject controller;
    private FrameLayout root;
    private ProcessCameraProvider provider;
    private ImageCapture capture;
    private androidx.camera.core.Camera boundCamera;
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private long lastScan = 0;
    private volatile int generation = 0;
    private volatile boolean captureBusy = false, scanPaused = false;
    private boolean front = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(16,23,19));
        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets safe = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            return insets;
        });
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        try {
            controller = Python.getInstance().getModule("main").callAttr("start", this);
        } catch (Exception error) {
            android.util.Log.e("LumaPython", "Python startup failed", error);
            TextView failure = new TextView(this);
            failure.setText("应用启动未完成，请保留照片数据后重试。\n" + error.getClass().getSimpleName());
            failure.setTextColor(Color.WHITE); failure.setPadding(30,80,30,30);
            root.addView(failure);
        }
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (controller == null || !controller.callAttr("on_back").toBoolean()) finish();
            }
        });
    }

    public void setMainContent(View content) {
        root.removeAllViews();
        root.addView(content, new FrameLayout.LayoutParams(-1,-1));
    }
    public String filesDirectory() { return getFilesDir().getAbsolutePath(); }
    public boolean darkMode() { return getPreferences(0).getBoolean("dark", false); }
    public void setDarkMode(boolean value) { getPreferences(0).edit().putBoolean("dark", value).apply(); }
    public int androidApi() { return Build.VERSION.SDK_INT; }
    public String cameraPermissionState() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) return "granted";
        if (!getPreferences(0).getBoolean("cameraAsked", false)) return "unasked";
        return ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA) ? "denied" : "blocked";
    }
    public void requestCameraPermission() {
        if (cameraPermissionState().equals("blocked")) { openPermissionSettings(); return; }
        getPreferences(0).edit().putBoolean("cameraAsked", true).apply();
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 100);
    }
    public void openPermissionSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
        catch (Exception error) { message("请手动打开系统设置 → LUMA 相机 → 权限。"); }
    }
    public void message(String value) { Toast.makeText(this, value, Toast.LENGTH_LONG).show(); }
    private void event(String name, Object... args) {
        runOnUiThread(() -> {
            if (controller == null || isDestroyed()) return;
            try { controller.callAttr(name, args); }
            catch (Exception error) { android.util.Log.e("LumaPython", "Callback failed: " + name, error); message("操作未完成，请重试。"); }
        });
    }
    @Override public void onResume() { super.onResume(); if (controller != null) controller.callAttr("on_resume"); }
    @Override public void onPause() { stopCamera(); super.onPause(); }
    @Override public void onDestroy() { stopCamera(); io.shutdown(); super.onDestroy(); }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (controller != null) controller.callAttr("on_permission_result", code);
    }

    public void stopCamera() {
        generation++;
        if (provider != null) provider.unbindAll();
        capture = null; boundCamera = null;
    }
    public void startCamera(FrameLayout holder, boolean useFront, int flashMode, boolean scanning, boolean grid) {
        stopCamera(); front = useFront; scanPaused = false;
        final int token = generation;
        PreviewView view = new PreviewView(this);
        view.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        view.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        holder.addView(view, 0, new FrameLayout.LayoutParams(-1,-1));
        if (grid && !scanning) holder.addView(new GridView(this), new FrameLayout.LayoutParams(-1,-1));
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            if (token != generation || isDestroyed()) return;
            try {
                provider = future.get();
                CameraSelector selector = useFront ? CameraSelector.DEFAULT_FRONT_CAMERA : CameraSelector.DEFAULT_BACK_CAMERA;
                if (!provider.hasCamera(selector)) { event("on_camera_error", "当前设备没有这个镜头，请切换其他镜头。"); return; }
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(view.getSurfaceProvider());
                capture = new ImageCapture.Builder().setFlashMode(flashMode).setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build();
                if (scanning) {
                    ImageAnalysis analysis = new ImageAnalysis.Builder().setTargetResolution(new android.util.Size(640,480)).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                    analysis.setAnalyzer(io, proxy -> analyze(proxy, token));
                    boundCamera = provider.bindToLifecycle(this, selector, preview, capture, analysis);
                } else boundCamera = provider.bindToLifecycle(this, selector, preview, capture);
                boundCamera.getCameraInfo().getCameraState().observe(this, state -> {
                    if (token != generation) return;
                    if (state.getType() == CameraState.Type.OPEN) event("on_camera_ready");
                    if (state.getError() != null) event("on_camera_error", "摄像头暂不可用，请检查是否被其他应用占用后重试。");
                });
            } catch (Exception error) { android.util.Log.w("LumaPython", "Camera unavailable", error); event("on_camera_error", "摄像头连接失败，请重试或切换镜头。"); }
        }, ContextCompat.getMainExecutor(this));
    }
    private void analyze(ImageProxy proxy, int token) {
        try {
            long now = SystemClock.elapsedRealtime();
            if (scanPaused || token != generation || now-lastScan < 250) return;
            lastScan = now;
            ImageProxy.PlaneProxy plane = proxy.getPlanes()[0];
            byte[] pixels = ScanDecoder.packLuminance(plane.getBuffer(),proxy.getWidth(),proxy.getHeight(),plane.getRowStride(),plane.getPixelStride());
            String value = ScanDecoder.decode(pixels,proxy.getWidth(),proxy.getHeight());
            if (value != null && token == generation && !scanPaused) {
                scanPaused = true; event("on_scan_result", value);
            }
        } catch (Exception error) { android.util.Log.w("LumaPython", "Frame unavailable", error); }
        finally { proxy.close(); }
    }
    public void resumeScanning() { scanPaused = false; }
    public boolean changeFlash(int mode) {
        if (boundCamera == null || capture == null) return false;
        if (!boundCamera.getCameraInfo().hasFlashUnit()) { message("当前镜头不支持闪光灯。"); return false; }
        capture.setFlashMode(mode); return true;
    }
    public void capturePhoto() {
        if (capture == null || captureBusy) return;
        captureBusy = true;
        File folder = new File(getFilesDir(), "photos"); folder.mkdirs();
        File output = new File(folder, UUID.randomUUID().toString() + ".jpg");
        ImageCapture.Metadata metadata = new ImageCapture.Metadata();
        metadata.setReversedHorizontal(front);
        ImageCapture.OutputFileOptions options = new ImageCapture.OutputFileOptions.Builder(output).setMetadata(metadata).build();
        capture.takePicture(options, io, new ImageCapture.OnImageSavedCallback() {
            @Override public void onImageSaved(ImageCapture.OutputFileResults result) {
                captureBusy = false;
                BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(output.getAbsolutePath(), bounds);
                event("on_photo_saved", output.getAbsolutePath(), bounds.outWidth, bounds.outHeight);
            }
            @Override public void onError(ImageCaptureException error) {
                captureBusy = false; output.delete(); event("on_capture_error", "拍照未完成，请保持相机在前台后重试。");
            }
        });
    }

    private File safePhoto(String path) throws IOException {
        File file = new File(path).getCanonicalFile();
        File photos = new File(getFilesDir(), "photos").getCanonicalFile();
        if (!file.getParentFile().equals(photos) || !file.isFile() || !file.getName().endsWith(".jpg")) throw new IOException("Invalid photo path");
        return file;
    }
    public void loadPhoto(ImageView target, String path, int limit) {
        target.setTag(path);
        io.execute(() -> {
            try {
                File file = safePhoto(path);
                BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = Math.max(1, Math.max(bounds.outWidth, bounds.outHeight) / limit);
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
                if (bitmap == null) return;
                ExifInterface exif = new ExifInterface(file);
                Matrix rotation = new Matrix(); rotation.postRotate(exif.getRotationDegrees());
                if (exif.isFlipped()) rotation.postScale(-1,1);
                Bitmap display = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),rotation,true);
                runOnUiThread(() -> { if (path.equals(target.getTag())) target.setImageBitmap(display); });
            } catch (Exception error) { android.util.Log.w("LumaPython", "Photo read failed", error); }
        });
    }
    public void savePhotoToSystem(String path) {
        if (Build.VERSION.SDK_INT <= 28 && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            boolean asked = getPreferences(0).getBoolean("storageAsked", false);
            if (asked && !ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                event("on_export_result", false, "保存权限已关闭，请到系统设置中恢复。", true); return;
            }
            getPreferences(0).edit().putBoolean("storageAsked", true).apply();
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
            event("on_export_result", false, "允许保存权限后，请再次点击存到手机。", false); return;
        }
        io.execute(() -> {
            Uri pending = null;
            try {
                File source = safePhoto(path);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, "LUMA_" + System.currentTimeMillis() + ".jpg");
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LUMA");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    pending = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (pending == null) throw new IOException("MediaStore insert failed");
                    try (InputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(pending)) {
                        if (out == null) throw new IOException("Output unavailable");
                        byte[] buffer = new byte[65536]; int length;
                        while ((length = in.read(buffer)) != -1) out.write(buffer,0,length);
                    }
                    ContentValues ready = new ContentValues(); ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(pending, ready, null, null); pending = null;
                } else {
                    File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "LUMA");
                    if (!folder.exists() && !folder.mkdirs()) throw new IOException("Directory unavailable");
                    File dest = new File(folder,"LUMA_" + System.currentTimeMillis() + ".jpg");
                    try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(dest)) {
                        byte[] buffer = new byte[65536]; int length;
                        while ((length = in.read(buffer)) != -1) out.write(buffer,0,length);
                    }
                    android.media.MediaScannerConnection.scanFile(this,new String[]{dest.getAbsolutePath()},new String[]{"image/jpeg"},null);
                }
                event("on_export_result", true, "已保存到手机相册 · Pictures/LUMA", false);
            } catch (Exception error) {
                if (pending != null) getContentResolver().delete(pending, null, null);
                event("on_export_result", false, "保存到手机失败，应用内原图仍会保留。", false);
            }
        });
    }
    public void sharePhoto(String path) {
        try {
            Uri uri = FileProvider.getUriForFile(this,getPackageName()+".files",safePhoto(path));
            Intent intent = new Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM,uri);
            intent.setClipData(ClipData.newRawUri("LUMA photo",uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent,"分享这个瞬间"));
        } catch (Exception error) { message("无法打开系统分享，请稍后重试。"); }
    }
    public void openWeb(String value) {
        Uri uri = Uri.parse(value); String scheme = uri.getScheme();
        if (!("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) || uri.getHost() == null) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
        catch (Exception error) { message("未找到可打开此网址的浏览器。"); }
    }
    public void copyText(String value) {
        ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("二维码内容",value));
        message("已复制二维码内容");
    }
    private static class GridView extends View {
        private final Paint paint = new Paint();
        GridView(Context context) { super(context); paint.setColor(0x55FFFFFF); paint.setStrokeWidth(1); setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO); }
        @Override protected void onDraw(Canvas canvas) {
            for (int i=1;i<3;i++) { float x=getWidth()*i/3f, y=getHeight()*i/3f; canvas.drawLine(x,0,x,getHeight(),paint); canvas.drawLine(0,y,getWidth(),y,paint); }
        }
    }
}
