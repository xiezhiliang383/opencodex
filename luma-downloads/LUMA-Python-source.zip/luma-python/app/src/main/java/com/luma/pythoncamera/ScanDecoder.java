package com.luma.pythoncamera;

import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

/** Offline QR decoder; no Google services, model download or network permission. */
public final class ScanDecoder {
    public static byte[] packLuminance(ByteBuffer source, int width, int height, int rowStride, int pixelStride) {
        byte[] pixels = new byte[width * height];
        int origin = source.position();
        for (int y=0; y<height; y++) for (int x=0; x<width; x++) {
            pixels[y*width+x] = source.get(origin + y*rowStride + x*pixelStride);
        }
        return pixels;
    }
    public static String decode(byte[] pixels, int width, int height) {
        PlanarYUVLuminanceSource source = new PlanarYUVLuminanceSource(pixels,width,height,0,0,width,height,false);
        Map<DecodeHintType,Object> hints = new EnumMap<>(DecodeHintType.class);
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Collections.singletonList(BarcodeFormat.QR_CODE));
        try { return new MultiFormatReader().decode(new BinaryBitmap(new HybridBinarizer(source)),hints).getText(); }
        catch (ReaderException error) { return null; }
    }
}
