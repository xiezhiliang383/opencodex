package com.luma.pythoncamera;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import org.json.JSONArray;
import org.json.JSONObject;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;
import java.io.*;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Runs on a single worker. Images and results never leave the device. */
public final class FoodClassifier implements AutoCloseable {
    private final Interpreter model;
    private final List<String> labels = new ArrayList<>();

    public FoodClassifier(Context context) throws IOException {
        try (AssetFileDescriptor asset = context.getAssets().openFd("food/mobilenet_v2.tflite");
             FileInputStream input = asset.createInputStream()) {
            MappedByteBuffer buffer = input.getChannel().map(FileChannel.MapMode.READ_ONLY, asset.getStartOffset(), asset.getDeclaredLength());
            model = new Interpreter(buffer, new Interpreter.Options().setNumThreads(2));
        }
        try {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(context.getAssets().open("food/labels.txt"), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) labels.add(line);
            }
            if (!Arrays.equals(model.getInputTensor(0).shape(), new int[]{1,224,224,3}) ||
                !Arrays.equals(model.getOutputTensor(0).shape(), new int[]{1,1001}) ||
                model.getInputTensor(0).dataType() != DataType.FLOAT32 || labels.size() != 1001)
                throw new IOException("Model input or label contract mismatch");
        } catch (IOException | RuntimeException error) { model.close(); throw error; }
    }

    public String classify(Bitmap upright) throws Exception {
        int side = Math.min(upright.getWidth(), upright.getHeight());
        Bitmap crop = Bitmap.createBitmap(upright, (upright.getWidth()-side)/2, (upright.getHeight()-side)/2, side, side);
        Bitmap resized = Bitmap.createScaledBitmap(crop,224,224,true);
        try {
            int[] pixels = new int[224*224];
            resized.getPixels(pixels,0,224,0,0,224,224);
            float[][] output = new float[1][labels.size()];
            model.run(FoodPixels.normalize(pixels),output);
            List<Integer> ranked = new ArrayList<>();
            for (int i=0; i<labels.size(); i++) ranked.add(i);
            ranked.sort((a,b) -> Float.compare(output[0][b], output[0][a]));
            JSONArray values = new JSONArray();
            for (int i=0;i<5;i++) {
                int index = ranked.get(i);
                values.put(new JSONObject().put("label",labels.get(index)).put("score",output[0][index]));
            }
            return values.toString();
        } finally {
            if (resized != crop && resized != upright) resized.recycle();
            if (crop != upright) crop.recycle();
        }
    }
    @Override public void close() { model.close(); }
}
