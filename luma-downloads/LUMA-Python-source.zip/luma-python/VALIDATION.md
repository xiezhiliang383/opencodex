# Python Android 验证记录

## 已产出

独立签名 APK：`artifacts/LUMA-Python-0.1.0.apk`。
该 APK 对应本目录 Python 工程，不是原 React Native 工程的资源包。

## 已通过

- Gradle release 原生构建成功，内嵌 ARM64 和 x86_64 的 CPython 3.12 运行时。
- APK v2 签名验证与 ZIP/16 KB 页面文件对齐检查。
- 实际 APK 清单检查：Android 7+，相机权限，旧式写入存储限定 API 28；无联网、麦克风、位置、悬浮窗或现代媒体读取权限。
- 内嵌 Python 源资源、原生运行库与 DEX 资源检查。
- Python 相册与交互规则：8 项通过，0 项失败。
- 离线扫码 JVM 测试：3 项通过，0 项失败，覆盖真实二维码图像解码、空画面、YUV 行/像素跨度。

## 未完成的运行验收

主机没有 `/dev/kvm`。已安装 Android 15 Google APIs 与 Android 11 AOSP 两种镜像，并尝试单核软件模拟。模拟器能够进入内核/系统进程阶段并连接 ADB，但 Android 安装服务始终未就绪（`Service package: not found`）。因此 APK 未能在模拟器完成安装启动验收，`scripts/emulator_smoke.py` 中的交互检查没有执行完成，不计为通过。

未连接真实手机，摄像头预览、镜头/闪光灯、真实二维码、系统授权弹框、系统相册导出和分享面板仍需真机验证。编译、签名和核心测试通过不等于这些硬件行为已通过。

真机顺序：安装 → 首次拒绝相机 → 相册/设置仍可使用 → 再次允许 → 拍照 → 重启照片保留 → 导出到手机相册 → 分享/取消 → 删除确认 → 切换镜头/闪光灯 → 后台释放相机 → 扫描真实二维码。

## 重现

```bash
python3 -m unittest discover -s tests -v
./gradlew :app:testQrDecoder
bash scripts/build.sh
```

最终校验记录见 `artifacts/apk-permissions.txt`、`artifacts/signature-verification.txt`、`artifacts/release-info.json` 和 APK 的 `.sha256` 文件。

原 `/workspace/mobile-shell` 与 `/workspace/opencodex` 保留不变。本 Python 项目不需要之前被拦截的 React Native 原生库域名。
